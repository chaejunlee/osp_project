#!/bin/bash

curl -X DELETE localhost:9200/_all

python app.py